Simpan logo, gambar, dan file portofolio asli Anda di folder ini.
